# E_Commerce_Retail Templates

- **shopify_order_sms.json** – Uses Anthropic Claude, Cohere Embeddings, Pinecone
- **inventory_slack_alert.json** – Uses Cohere Embeddings, OpenAI Chat, Pinecone
- **abandoned_cart_email.json** – Uses Cohere Embeddings, OpenAI Chat, Supabase Vector